#!/usr/bin/env python

import rospy
import math
import time
from sensor_msgs.msg import JointState
from std_msgs.msg import Header

class RobotController:
    def __init__(self):
        rospy.init_node('robot_controller', anonymous=True)
        
        self.joint_pub = rospy.Publisher('/joint_states', JointState, queue_size=10)
        self.joint_names = ['joint1', 'joint2', 'joint3']
        self.current_positions = [0.0, 0.0, 0.0]
        self.rate = rospy.Rate(30)  # 30 Hz для плавности
        
    def publish_joint_states(self):
        joint_state = JointState()
        joint_state.header = Header()
        joint_state.header.stamp = rospy.Time.now()
        joint_state.name = self.joint_names
        joint_state.position = self.current_positions
        self.joint_pub.publish(joint_state)
    
    def smooth_move_to(self, target_pos, duration=4.0):
        """Плавное перемещение к целевой позиции"""
        rospy.loginfo("Moving to: " + str(target_pos))
        
        start_pos = self.current_positions[:]
        steps = int(duration * 30)
        
        for step in range(steps):
            if rospy.is_shutdown():
                return
                
            t = float(step) / steps
            t_smooth = t * t * (3 - 2 * t)  # Плавная интерполяция
            
            for i in range(3):
                self.current_positions[i] = start_pos[i] + (target_pos[i] - start_pos[i]) * t_smooth
            
            self.publish_joint_states()
            self.rate.sleep()
        
        self.current_positions = target_pos[:]
        self.publish_joint_states()
    
    def move_to_home_position(self):
        """Перемещает робота в домашнюю позицию"""
        rospy.loginfo("Moving to home position...")
        self.smooth_move_to([0.0, 0.0, 0.0], duration=3.0)
        time.sleep(1)
    
    def sinusoidal_movement(self, duration=15.0):
        """Синусоидальное движение всех суставов"""
        rospy.loginfo("Starting sinusoidal movement...")
        start_time = time.time()
        
        while time.time() - start_time < duration and not rospy.is_shutdown():
            t = time.time() - start_time
            freq = 0.3  # Медленная частота
            
            pos1 = math.sin(2 * math.pi * freq * t) * 1.0
            pos2 = math.sin(2 * math.pi * freq * t + math.pi/3) * 0.8
            pos3 = math.sin(2 * math.pi * freq * t + 2*math.pi/3) * 0.5
            
            self.current_positions = [pos1, pos2, pos3]
            self.publish_joint_states()
            self.rate.sleep()
    
    def sequential_movement(self):
        """Последовательное движение каждого сустава"""
        rospy.loginfo("Starting sequential movement...")
        
        # Двигаем joint1 медленно
        rospy.loginfo("Moving joint1...")
        for angle in range(0, 314, 5):  # Меньший шаг
            self.current_positions = [angle/100.0, 0.0, 0.0]
            self.publish_joint_states()
            self.rate.sleep()
        
        for angle in range(314, -314, -5):
            self.current_positions = [angle/100.0, 0.0, 0.0]
            self.publish_joint_states()
            self.rate.sleep()
        
        # Двигаем joint2
        rospy.loginfo("Moving joint2...")
        for angle in range(0, 157, 3):
            self.current_positions = [0.0, angle/100.0, 0.0]
            self.publish_joint_states()
            self.rate.sleep()
        
        for angle in range(157, -157, -3):
            self.current_positions = [0.0, angle/100.0, 0.0]
            self.publish_joint_states()
            self.rate.sleep()
        
        # Двигаем joint3
        rospy.loginfo("Moving joint3...")
        for angle in range(0, 100, 2):
            self.current_positions = [0.0, 0.0, angle/100.0]
            self.publish_joint_states()
            self.rate.sleep()
        
        for angle in range(100, -100, -2):
            self.current_positions = [0.0, 0.0, angle/100.0]
            self.publish_joint_states()
            self.rate.sleep()
    
    def demo_sequence(self):
        """Демонстрационная последовательность с паузами"""
        rospy.loginfo("Starting demo sequence...")
        
        sequences = [
            [1.0, 0.0, 0.0],
            [0.0, 0.5, 0.0],
            [0.0, 0.0, 0.3],
            [-1.0, -0.5, -0.3],
            [0.0, 0.0, 0.0]
        ]
        
        for pos in sequences:
            self.smooth_move_to(pos, duration=3.0)
            rospy.loginfo("Position reached. Pausing...")
            time.sleep(1)  # Пауза между движениями

    def interactive_control(self):
        """Интерактивное управление через терминал"""
        rospy.loginfo("Interactive control mode")
        rospy.loginfo("Commands: 1 - Home, 2 - Sinusoidal, 3 - Sequential, 4 - Demo, q - Quit")
        
        while not rospy.is_shutdown():
            try:
                command = input("Enter command: ").strip().lower()
                
                if command == 'q':
                    break
                elif command == '1':
                    self.move_to_home_position()
                elif command == '2':
                    self.sinusoidal_movement(duration=10.0)
                elif command == '3':
                    self.sequential_movement()
                elif command == '4':
                    self.demo_sequence()
                else:
                    rospy.logwarn("Unknown command")
                    
            except EOFError:
                break
            except Exception as e:
                rospy.logerr("Error: " + str(e))

def main():
    try:
        controller = RobotController()
        
        rospy.loginfo("Controller initialized. Waiting...")
        time.sleep(2)
        
        controller.move_to_home_position()
        
        # Автоматическая демонстрация
        controller.demo_sequence()
        
        # Интерактивное управление
        controller.interactive_control()
        
        rospy.loginfo("Controller finished!")
        
    except rospy.ROSInterruptException:
        pass
    except Exception as e:
        rospy.logerr("Controller error: " + str(e))

if __name__ == '__main__':
    main()